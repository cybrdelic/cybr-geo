"""Bounded in-memory timing sensitivity on verified P5 native-derived inputs.

No project, geometry, physical constants or source numeric thresholds change.
These are experimental references, not the checked-in default's acceptance.
"""
from pathlib import Path
from copy import deepcopy
from concurrent.futures import ProcessPoolExecutor, as_completed
import argparse
import gzip
import hashlib
import importlib
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
import check_arx_faults as maintained
from mechanism_lab.engineering_source import load_project, verify_native_build, verify_native_source_binding, assert_project_source_identity
from mechanism_lab.physical_model import digest
from mechanism_lab.reference_clock import PhaseClock

WORKER=None
SCRIPT_SHA=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def write(path,value):
    path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')


def initialize(snapshot):
    global WORKER
    project,files=load_project('arx_belt')
    if files!=snapshot['source_files'] or maintained._engine_identity()!=snapshot['engine_files_sha256']:
        raise ValueError('Current source/runtime no longer matches verified input snapshot')
    task=importlib.import_module(project.construct.__module__.rsplit('.',1)[0]+'.task')
    WORKER=snapshot,maintained._fault_module(project),task.reference


def one(job):
    snapshot,faults,source_reference=WORKER
    parameters=deepcopy(job['parameters'])
    clock=PhaseClock.from_source(parameters['reference_clock'])
    bound=clock.bind(source_reference,parameters,**snapshot['join_validation'])
    if parameters['reference_clock_validation']!=bound.validation_report:
        raise ValueError('Experimental clock validation changed')
    assert_project_source_identity('arx_belt',snapshot['source_files'])
    result=faults.run_case(snapshot['physical_source'],snapshot['control'],parameters,bound,job['case'],
        reference_source=dict(source_files=snapshot['source_files'],task_parameters=parameters,
            experiment=dict(script_sha256=SCRIPT_SHA,policy=job['policy'],baseline_input_sha256=snapshot['baseline_input_sha256'],
                scope='Ephemeral PhaseClock on unchanged pinned P5 source task; same native mass/physical/controller inputs; not checked-in default acceptance')))
    assert_project_source_identity('arx_belt',snapshot['source_files'])
    if maintained._engine_identity()!=snapshot['engine_files_sha256']:
        raise ValueError('Runtime changed during diagnostic')
    folder=Path(snapshot['output'])/job['policy']/job['case']['id'];folder.mkdir(parents=True,exist_ok=False)
    trace=gzip.compress(json.dumps(result,separators=(',',':'),allow_nan=False).encode(),mtime=0)
    (folder/'trace.json.gz').write_bytes(trace)
    checks=result['source_case_requirements']
    checks.update(trace_sha256=hashlib.sha256(trace).hexdigest(),runtime_implementation=result['runtime_implementation'],
        native_build_sha256=snapshot['native_build_sha256'],native_source_binding_sha256=snapshot['native_source_binding_sha256'])
    write(folder/'checks.json',checks)
    return dict(policy=job['policy'],case=job['case']['id'],passed=checks['passed'],expected_outcome_observed=checks['expected_outcome_observed'],
        failed=[x for x in checks['checks']+checks['task_outcome_checks'] if not x['passed']],
        max_speed_after_fault_deadline_rad_s=checks['max_speed_after_fault_deadline_rad_s'],
        max_fault_travel_deg=checks['max_fault_travel_deg'],payload=checks['payload'],trace_sha256=checks['trace_sha256'])


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--transfer-rate',type=float,action='append',required=True)
    parser.add_argument('--descent-rate',type=float,default=.2)
    parser.add_argument('--case',action='append',required=True)
    parser.add_argument('--clock',action='append',choices=['original-clock','matched-phase'])
    parser.add_argument('--timestep-scale',type=float,choices=[1.,.5],default=1.)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--workers',type=int,choices=range(1,5),default=3)
    args=parser.parse_args()
    raw=(ROOT/'outputs/engineering-arx-faults-final/inputs.json').read_bytes();snapshot=json.loads(raw)
    project,files=load_project('arx_belt')
    assert files==snapshot['source_files'] and maintained._engine_identity()==snapshot['engine_files_sha256']
    receipt=verify_native_build(snapshot['native_directory'],project.specification,source_files=files)
    binding=verify_native_source_binding(snapshot['native_directory'],project.specification,files,receipt=receipt)
    assert digest(receipt)==snapshot['native_build_sha256'] and digest(binding)==snapshot['native_source_binding_sha256']
    task=importlib.import_module(project.construct.__module__.rsplit('.',1)[0]+'.task')
    faults=maintained._fault_module(project)
    snapshot.update(baseline_input_sha256=hashlib.sha256(raw).hexdigest(),output=str(args.output.resolve()),
        diagnostic_script_sha256=SCRIPT_SHA,join_validation=project.specification['task_timing']['join_validation'])
    jobs=[]
    for rate in args.transfer_rate:
        if not 0<rate<=1 or not 0<args.descent_rate<=1:raise ValueError('Only bounded slow reference rates are supported here')
        source=[0.,1.65,2.75,3.4,5.,6.65,7.75,8.4,10.]
        rates=[1.,rate,args.descent_rate,1.,1.,rate,args.descent_rate,1.]
        times=[0.]
        for a,b,r in zip(source,source[1:],rates):times.append(times[-1]+(b-a)/r)
        clock=PhaseClock(tuple(source),tuple(times))
        parameters=deepcopy(snapshot['task_parameters']);parameters['reference_clock']=clock.source()
        parameters['reference_clock_validation']=clock.bind(task.reference,parameters,**snapshot['join_validation']).validation_report
        policy=f'transfer-{rate:g}-descent-{args.descent_rate:g}-dt-{args.timestep_scale:g}'
        cases=faults.scheduled_cases(parameters,args.case,clocks=args.clock or ('original-clock','matched-phase'))
        if args.timestep_scale!=1.:
            for case in cases:case.update(timestep_s=.000416666666667*args.timestep_scale,timestep_scale=args.timestep_scale)
        jobs += [dict(policy=policy,case=case,parameters=parameters) for case in cases]
    args.output.mkdir(parents=True,exist_ok=False)
    snapshot['jobs']=jobs;write(args.output/'inputs.json',snapshot)
    results=[]
    with ProcessPoolExecutor(max_workers=args.workers,initializer=initialize,initargs=(snapshot,)) as pool:
        futures=[pool.submit(one,job) for job in jobs]
        for future in as_completed(futures):
            row=future.result();results.append(row);print(json.dumps(row),flush=True)
            write(args.output/'progress.json',dict(completed=len(results),total=len(jobs),results=results))
    assert_project_source_identity('arx_belt',files)
    verify_native_build(snapshot['native_directory'],project.specification,source_files=files)
    write(args.output/'summary.json',dict(complete=True,results=results,input_sha256=hashlib.sha256((args.output/'inputs.json').read_bytes()).hexdigest(),
        native_build_sha256=snapshot['native_build_sha256'],native_source_binding_sha256=snapshot['native_source_binding_sha256'],
        scope='Pinned P5 in-memory reference timing experiments only; no new authored project or hardware claim'))


if __name__=='__main__':main()
