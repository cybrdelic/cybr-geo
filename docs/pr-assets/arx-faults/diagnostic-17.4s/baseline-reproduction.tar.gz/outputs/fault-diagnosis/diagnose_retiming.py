"""Output-only local retiming sensitivity; physical model/acceptance unchanged."""
from pathlib import Path
import argparse, json
import diagnose_shared as diagnostic
from mechanism_lab.engineering_source import (load_project, verify_native_build,
    verify_native_source_binding, assert_project_source_identity)
from mechanism_lab.physical_model import digest

def time_map(transfer, descent):
    phases = [0., 1.65, 2.75, 3.4, 5., 6.65, 7.75, 8.4, 10.]
    rates = [1., transfer, descent, 1., 1., transfer, descent, 1.]
    physical = [0.]
    for a,b,r in zip(phases,phases[1:],rates):
        physical.append(physical[-1]+(b-a)/r)
    def physical_time(phase):
        for i,(a,b) in enumerate(zip(phases,phases[1:])):
            if phase <= b:
                return physical[i]+(phase-a)/rates[i]
        raise ValueError(phase)
    def source_time(t):
        cycle = int(t//physical[-1]); local = t-cycle*physical[-1]
        for i,(a,b) in enumerate(zip(physical,physical[1:])):
            if local < b or i==len(rates)-1:
                return cycle*10+phases[i]+(local-a)*rates[i], rates[i]
        raise ValueError(t)
    return physical_time, source_time, dict(source_edges_s=phases, physical_edges_s=physical, rates=rates)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--transfer',type=float,default=.5)
    parser.add_argument('--descent',type=float,default=.2)
    args=parser.parse_args()
    project, files=load_project('arx_belt')
    native=diagnostic.ROOT/'outputs/engineering-arx-sourcebound/native'
    receipt=verify_native_build(native,project.specification,source_files=files)
    binding=verify_native_source_binding(native,project.specification,files,receipt=receipt)
    physical,control,p=project.compile_physics(project.specification,native_directory=native)
    physical.provenance.update(design_source_files=files,native_build_sha256=digest(receipt),native_source_binding_sha256=digest(binding))
    forward,inverse,mapping=time_map(args.transfer,args.descent)
    provenance=dict(source_files=files,native_build_sha256=digest(receipt),native_source_binding_sha256=digest(binding),
        diagnostic_script_sha256=diagnostic.sha(__file__),measurement_script_sha256=diagnostic.sha(diagnostic.__file__),
        retiming=mapping,scope='In-memory sensitivity only; no geometry, physical constants, source files or thresholds changed')
    def reference(t):
        phase,rate=inverse(t)
        target=project.reference(phase,p)
        target['qd']=[v*rate for v in target['qd']]
        target['qdd']=[a*rate*rate for a in target['qdd']]
        return target
    root=diagnostic.ROOT/'outputs/fault-diagnosis/local-retiming'/f'transfer-{args.transfer:g}-descent-{args.descent:g}'
    summaries=[]
    for name,(_,base_options) in list(diagnostic.CASES.items()):
        for scope in ('original-clock','matched-phase'):
            options=dict(base_options)
            if scope=='matched-phase':
                options['motorOffTime']=forward(options['motorOffTime'])
            label=f'{name}--{scope}'
            diagnostic.CASES[label]=(options['motorOffTime']+1.2,options)
            summary=diagnostic.diagnose(label,physical,control,p,reference,provenance,root/label)
            summaries.append(dict(case=name,scope=scope,fault_s=options['motorOffTime'],
                source_phase_at_fault_s=inverse(options['motorOffTime'])[0],passed=summary['passed'],
                failed=[c['name'] for c in summary['checks'] if not c['passed']],peak_belt_Nm=summary['peak_belt_Nm'],
                max_settled_speed_sampled_rad_s=summary['max_settled_speed_sampled_rad_s'],
                max_fault_puck_drop_m=summary['max_fault_puck_drop_m'],diagnosis=str(root/label/'diagnosis.json')))
    diagnostic.write(root/'summary.json',dict(retiming=mapping,scenarios=summaries))
    assert_project_source_identity('arx_belt',files)
    print(json.dumps(summaries,indent=2),flush=True)

if __name__=='__main__':
    main()
