"""Read-only fault diagnosis: unchanged shared runtime, source acceptance rules.

Acceptance follows pinned ARX validate_p5.mjs; high-rate event details follow
diagnose_p5_brakes.mjs. This output-only harness does not modify project/core.
"""
from pathlib import Path
import argparse, gzip, hashlib, json, math, time
import numpy as np

from mechanism_lab.causal_runtime import CausalSimulation
from mechanism_lab.engineering_source import (load_project, verify_native_build,
    verify_native_source_binding, assert_project_source_identity)
from mechanism_lab.physical_model import digest

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT.parent/'arx-belt-source/ARX-6-P5-Engineering/integration'
CASES = {
    'power_loss_3.2': (4.4, dict(motorOffTime=3.2)),
    'weak_spring_double_delay_3.2': (4.4, dict(motorOffTime=3.2, springScale=.9, brakeDelayScale=2)),
    'weak_spring_double_delay_7.2': (8.4, dict(motorOffTime=7.2, springScale=.9, brakeDelayScale=2)),
}

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n', encoding='utf-8')

def diagnose(name, physical, control, parameters, reference, provenance, directory):
    seconds, options = CASES[name]
    started = time.monotonic()
    sim = CausalSimulation(physical, control, reference, options=options,
        reference_source=dict(provenance=provenance, task_parameters=parameters))
    m, d, mj = sim.model, sim.data, sim.mj
    dt, stride = float(m.opt.timestep), round(1/(120*m.opt.timestep))
    total = round(seconds/dt)
    qa, va = sim.qadr, sim.vadr
    puck = m.body('puck').id
    pj = int(m.body_jntadr[puck]); pq, pv = int(m.jnt_qposadr[pj]), int(m.jnt_dofadr[pj])
    tcp = m.site('tcp').id
    limits = np.asarray(parameters['integration']['joint_hard_limits_rad'])
    raw = np.asarray(parameters['motors']['belt_screen_capacity_Nm'])
    allowance = np.asarray(parameters['motors']['belt_allowable_output_torque_Nm'])
    peaks, times, above, above_raw = (np.zeros(6) for _ in range(4))
    peak_events = [None]*6
    drift, drift_sample, settled_step, settled_sample = (np.zeros(6) for _ in range(4))
    last_above = [None]*6
    brake_peak, capacity_peak = np.zeros(6), np.zeros(6)
    fault_q = fault_puck = fault_tcp = fault_time = None
    min_margin, max_structure, max_pen = math.inf, 0., 0.
    max_grip, grip_over, max_force = 0., 0., 0.
    drop_step = drop_sample = tcp_drift = 0.
    pair_max, frames, event_rows = {}, [], []
    force = np.zeros(6)

    def contacts():
        nonlocal max_structure, max_pen
        rows = []
        for k in range(d.ncon):
            c = d.contact[k]
            names = [sim.geom_names[c.geom1], sim.geom_names[c.geom2]]
            pen = max(0., -float(c.dist)); max_pen = max(max_pen, pen)
            if 'puck' not in names:
                max_structure = max(max_structure, pen)
            if c.dist <= 0:
                mj.mj_contactForce(m, d, k, force)
                rows.append(dict(pair=names, distance_m=float(c.dist), normal_N=float(force[0]),
                    tangent_N=float(np.linalg.norm(force[1:3]))))
        return rows

    def capture():
        nonlocal drop_sample, tcp_drift
        frame = sim.frame()
        frames.append(frame)
        if fault_q is not None:
            drift_sample[:] = np.maximum(drift_sample, np.abs(d.qpos[qa]-fault_q))
            drop_sample = max(drop_sample, float(fault_puck[1]-d.qpos[pq+1]))
            tcp_drift = max(tcp_drift, float(np.linalg.norm(d.site_xpos[tcp]-fault_tcp)))
            if frame['time_s'] > fault_time+.5:
                settled_sample[:] = np.maximum(settled_sample, np.abs(d.qvel[va]))

    capture(); contacts()
    for k in range(total):
        before, velocity, before_puck = d.qpos[qa].copy(), d.qvel[va].copy(), d.qpos[pq:pq+3].copy()
        before_tcp = d.site_xpos[tcp].copy()
        sim.step()
        t = sim.steps*dt
        cs = contacts()
        acceleration = (d.qvel[va]-velocity)/dt
        motor_torque = np.asarray([x.state.torque_Nm for x in sim.motors])
        belt = motor_torque-m.dof_armature[va]*acceleration
        if fault_q is None and sim.safety.fault_time_s is not None:
            fault_q, fault_puck, fault_tcp = before, before_puck, before_tcp
            fault_time = sim.safety.fault_time_s
        min_margin = min(min_margin, float(np.min(d.qpos[qa]-limits[:,0])), float(np.min(limits[:,1]-d.qpos[qa])))
        grip = abs(sim.rack_motor.state.current_A)
        max_grip = max(max_grip, grip)
        grip_over += dt if grip > parameters['gripper']['continuous_current_A']+1e-6 else 0.
        max_force = max(max_force, float(np.max(np.abs(d.qfrc_applied[pv:pv+6]))), float(np.max(np.abs(d.xfrc_applied[puck]))))
        brake_peak[:] = np.maximum(brake_peak, np.abs(sim.brake_torque))
        capacity_peak[:] = np.maximum(capacity_peak, sim.brake_capacity)
        for j in range(6):
            if abs(belt[j]) > peaks[j]:
                peaks[j], times[j] = abs(belt[j]), t
                peak_events[j] = dict(time_s=t, joint=f'j{j+1}', belt_Nm=float(belt[j]),
                    pre_q=before.tolist(), q=d.qpos[qa].tolist(), pre_qvel=velocity.tolist(), qvel=d.qvel[va].tolist(),
                    acceleration_rad_s2=acceleration.tolist(), motor_torque_Nm=motor_torque.tolist(),
                    current_A=[x.state.current_A for x in sim.motors], brake_capacity_Nm=sim.brake_capacity.tolist(),
                    brake_torque_Nm=sim.brake_torque.tolist(), qfrc_constraint=d.qfrc_constraint[va].tolist(),
                    qfrc_bias=d.qfrc_bias[va].tolist(), qfrc_applied=d.qfrc_applied[va].tolist(), contacts=cs,
                    puck_qpos=d.qpos[pq:pq+7].tolist(), puck_qvel=d.qvel[pv:pv+6].tolist())
        above += (np.abs(belt)>allowance)*dt
        above_raw += (np.abs(belt)>raw)*dt
        if fault_q is not None:
            drift[:] = np.maximum(drift, np.abs(d.qpos[qa]-fault_q))
            drop_step = max(drop_step, float(fault_puck[1]-d.qpos[pq+1]))
            for j in range(6):
                if abs(d.qvel[va[j]]) > .002:
                    last_above[j] = t
            if t > fault_time+.5:
                settled_step[:] = np.maximum(settled_step, np.abs(d.qvel[va]))
            for c in cs:
                key = ' / '.join(sorted(c['pair']))
                if key not in pair_max or c['normal_N'] > pair_max[key]['normal_N']:
                    pair_max[key] = dict(c, time_s=t)
            event_rows.append(dict(time_s=t, q=d.qpos[qa].tolist(), qvel=d.qvel[va].tolist(), belt_Nm=belt.tolist(),
                brake_capacity_Nm=sim.brake_capacity.tolist(), brake_torque_Nm=sim.brake_torque.tolist(),
                current_A=[x.state.current_A for x in sim.motors], gripper_current_A=sim.rack_motor.state.current_A,
                puck_qpos=d.qpos[pq:pq+7].tolist(), puck_qvel=d.qvel[pv:pv+6].tolist(), contacts=cs))
        if (k+1)%stride==0 or k+1==total:
            capture()
        if (k+1)%2400==0:
            print(f'{name}: {t:.2f}/{seconds:.2f} s integrated', flush=True)
    monitor, motors = sim.monitor, parameters['motors']
    checks = []
    def check(name, passed, measured, limit):
        checks.append(dict(name=name, passed=bool(passed), measured=measured, limit=limit))
    check('all integrated states finite', all(np.isfinite(f['qpos']+f['qvel']).all() for f in frames), True, True)
    check('hard travel bounds respected', min_margin>=-1e-4, min_margin, -1e-4)
    check('no structural proxy penetration over 0.1 mm', max_structure<1e-4, max_structure, 1e-4)
    check('no imposed force on independent free workpiece', max_force==0, max_force, 0)
    mt = [x['peak_output_torque_Nm'] for x in monitor]
    check('motor-generated output torque within belt service allowance', np.all(np.asarray(mt)<=allowance+1e-5), mt, allowance.tolist())
    check('estimated belt torque including rotor deceleration within service allowance', np.all(peaks<=allowance+1e-5), peaks.tolist(), allowance.tolist())
    currents = [x['peak_current_A'] for x in monitor]
    check('configured arm peak current ceilings', np.all(np.asarray(currents)<=np.asarray(motors['peak_current_A'])+1e-5), currents, motors['peak_current_A'])
    check('configured gripper peak current ceiling', max_grip<=.35+1e-6, max_grip, .35)
    speed = np.asarray([x['peak_motor_speed_rad_s'] for x in monitor]); rpm = speed/np.asarray(motors['gear_ratio'])*60/(2*math.pi)
    check('belt pulley speed within handbook low-speed screen', np.all(rpm<=200), rpm.tolist(), 200)
    check('motor input speed ratings', np.all(speed<=motors['gear_max_input_speed_rad_s']), speed.tolist(), motors['gear_max_input_speed_rad_s'])
    volts = np.asarray([x['peak_voltage_V'] for x in monitor]); vmax = np.asarray(motors['bus_voltage_V'])*motors['max_pwm_duty']
    check('voltage ceilings', np.all(volts<=vmax+1e-6), volts.tolist(), vmax.tolist())
    check('all drives disabled after emergency', all(abs(x.state.current_A)<1e-12 for x in sim.motors) and sim.rack_motor.state.current_A==0,
        [x.state.current_A for x in sim.motors]+[sim.rack_motor.state.current_A], 0)
    check('all joints settle below 0.002 rad/s', float(max(settled_sample))<.002, float(max(settled_sample)), .002)
    energy_limit = [parameters['integration']['brakes']['large' if i<3 else 'small']['max_single_stop_energy_J'] for i in range(6)]
    check('model brake work below catalog event-energy ceiling', np.all(sim.brake_energy<energy_limit), sim.brake_energy.tolist(), energy_limit)
    result = dict(schema='cybrgeo-readonly-fault-diagnosis/1', case=name, options=options,
        duration_s=total*dt, timestep_s=dt, frames=len(frames), steps=total, wall_time_s=time.monotonic()-started,
        model_sha256=sim.model_sha256, control_sha256=digest(control), reference_sha256=sim.reference_sha256,
        provenance=provenance, acceptance_source='Pinned integration/validate_p5.mjs, unchanged numeric thresholds; settling sampled at 120 Hz as source',
        passed=all(c['passed'] for c in checks), checks=checks, events=sim.safety.events, fault_time_s=fault_time,
        belt_allowance_Nm=allowance.tolist(), belt_raw_screen_Nm=raw.tolist(), upstream_armature_kg_m2=m.dof_armature[va].tolist(),
        peak_belt_Nm=peaks.tolist(), peak_belt_time_s=times.tolist(), above_allowance_s=above.tolist(), above_raw_s=above_raw.tolist(),
        peak_events=peak_events, peak_current_A=currents, peak_gripper_current_A=max_grip,
        rms_current_A=[math.sqrt(x.state.current_squared_integral_A2_s/(total*dt)) for x in sim.motors],
        gripper_over_continuous_s=grip_over, brake_peak_actual_Nm=brake_peak.tolist(), brake_peak_capacity_Nm=capacity_peak.tolist(),
        brake_energy_J=sim.brake_energy.tolist(), max_fault_travel_deg=(drift_sample*180/math.pi).tolist(),
        max_fault_travel_every_step_deg=(drift*180/math.pi).tolist(), max_settled_speed_sampled_rad_s=settled_sample.tolist(),
        max_settled_speed_every_step_rad_s=settled_step.tolist(), last_time_speed_over_0p002_rad_s=last_above,
        max_fault_puck_drop_m=drop_sample, max_fault_puck_drop_every_step_m=drop_step, max_fault_tcp_travel_m=tcp_drift,
        retention_scope='Reported observation only; original ordinary fault criteria do not require payload retention',
        min_hard_margin_rad=min_margin, max_structural_penetration_m=max_structure, max_penetration_m=max_pen,
        peak_post_fault_contacts=pair_max, final_puck_position_m=d.qpos[pq:pq+3].tolist(),
        final_joint_speed_rad_s=d.qvel[va].tolist(), qualification='Numerical rigid-body/contact diagnostic, no hardware qualification')
    directory.mkdir(parents=True, exist_ok=False)
    write(directory/'diagnosis.json', result)
    (directory/'event-steps.json.gz').write_bytes(gzip.compress(json.dumps(event_rows, separators=(',',':'), allow_nan=False).encode(), mtime=0))
    (directory/'frames.json.gz').write_bytes(gzip.compress(json.dumps(frames, separators=(',',':'), allow_nan=False).encode(), mtime=0))
    print(json.dumps(dict(case=name, failed=[c['name'] for c in checks if not c['passed']], peak_belt_Nm=peaks.tolist(),
        settled_sampled=settled_sample.tolist(), puck_drop_m=drop_sample, wall_time_s=result['wall_time_s'])), flush=True)
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', choices=CASES, action='append')
    args = parser.parse_args()
    project, files = load_project('arx_belt')
    native = ROOT/'outputs/engineering-arx-sourcebound/native'
    receipt = verify_native_build(native, project.specification, source_files=files)
    binding = verify_native_source_binding(native, project.specification, files, receipt=receipt)
    physical, control, parameters = project.compile_physics(project.specification, native_directory=native)
    physical.provenance['design_source_files'] = files
    physical.provenance['native_build_sha256'] = digest(receipt)
    physical.provenance['native_source_binding_sha256'] = digest(binding)
    provenance = dict(source_files=files, native_build_sha256=digest(receipt), native_source_binding_sha256=digest(binding),
        diagnostic_script_sha256=sha(__file__), source_commit='aabdf8c57a4ee64f77b8a246ad9aca7b51d9cba2',
        source_validator_lf_sha256=hashlib.sha256((SOURCE/'validate_p5.mjs').read_bytes().replace(b'\r\n',b'\n')).hexdigest())
    print(json.dumps(dict(native_verified=True, model_sha256=digest(physical.to_source()), control_sha256=digest(control))), flush=True)
    for name in args.case or CASES:
        diagnose(name, physical, control, parameters, lambda t: project.reference(t, parameters), provenance,
            ROOT/'outputs/fault-diagnosis'/name)
    assert_project_source_identity('arx_belt', files)
    verify_native_build(native, project.specification, source_files=files)

if __name__=='__main__':
    main()
