"""Historical-baseline trajectory policies; no project/core changes."""
import argparse, json, math, gzip
import numpy as np
import diagnose_shared as diagnostic
from diagnose_retiming import time_map
from baseline_runtime.causal_runtime import CausalSimulation
from baseline_runtime.physical_model import PhysicalModel, digest
diagnostic.CausalSimulation = CausalSimulation
diagnostic.digest = digest

def nominal(physical,control,p,reference,provenance,forward,out):
    sim=CausalSimulation(physical,control,reference,reference_source=provenance)
    m,d=sim.model,sim.data
    original_step=sim.step
    peak_belt=np.zeros(6); max_structure=0.; min_margin=math.inf; peak_grip=0.
    limits=np.asarray(p['integration']['joint_hard_limits_rad'])
    def step():
        nonlocal max_structure,min_margin,peak_grip
        before=d.qvel[sim.vadr].copy()
        original_step()
        torque=np.asarray([x.state.torque_Nm for x in sim.motors])
        peak_belt[:]=np.maximum(peak_belt,np.abs(torque-m.dof_armature[sim.vadr]*(d.qvel[sim.vadr]-before)/m.opt.timestep))
        min_margin=min(min_margin,float(np.min(d.qpos[sim.qadr]-limits[:,0])),float(np.min(limits[:,1]-d.qpos[sim.qadr])))
        peak_grip=max(peak_grip,abs(sim.rack_motor.state.current_A))
        for c in d.contact:
            if 'puck' not in [sim.geom_names[c.geom1],sim.geom_names[c.geom2]]:
                max_structure=max(max_structure,-float(c.dist))
    sim.step=step
    result=sim.run(forward(10.),output_hz=120)
    checks=[]
    def check(name,passed,measured,limit):
        checks.append(dict(name=name,passed=bool(passed),measured=measured,limit=limit))
    check('completed without safety trip',not result['events'],result['events'],[])
    check('hard travel bounds respected',min_margin>=-1e-4,min_margin,-1e-4)
    check('no structural proxy penetration over 0.1 mm',max_structure<1e-4,max_structure,1e-4)
    allowance=np.asarray(p['motors']['belt_allowable_output_torque_Nm'])
    check('estimated belt torque including rotor deceleration within service allowance',np.all(peak_belt<=allowance+1e-5),peak_belt.tolist(),allowance.tolist())
    monitor=list(result['metrics']['actuators'].values())
    for name,key,limit in [('motor-generated output torque within belt service allowance','peak_output_torque_Nm',allowance),
                           ('configured arm peak current ceilings','peak_current_A',np.asarray(p['motors']['peak_current_A'])),
                           ('arm RMS currents below continuous ratings','rms_current_A',np.asarray(p['motors']['continuous_current_A'])),
                           ('motor input speed ratings','peak_motor_speed_rad_s',np.asarray(p['motors']['gear_max_input_speed_rad_s'])),
                           ('voltage ceilings','peak_voltage_V',np.asarray(p['motors']['bus_voltage_V'])*p['motors']['max_pwm_duty'])]:
        values=np.asarray([x[key] for x in monitor]); tolerance=0 if key in ['rms_current_A','peak_motor_speed_rad_s'] else 1e-5
        check(name,np.all(values<=limit+tolerance),values.tolist(),limit.tolist())
    check('configured gripper peak current ceiling',peak_grip<=.350001,peak_grip,.35)
    check('no externally applied body wrench',result['metrics']['max_external_body_force_N']==0,result['metrics']['max_external_body_force_N'],0)
    for phase,target in [(4.9,'B'),(9.9,'A')]:
        desired_time=forward(phase)
        frame=min(result['frames'],key=lambda f:abs(f['time_s']-desired_time))
        error=float(np.linalg.norm(np.asarray(frame['bodies']['puck']['position_m'])-p['workpiece_targets_m'][target]))
        check('placement '+target+' within 1.5 mm',error<.0015,error,.0015)
    out.mkdir(parents=True,exist_ok=False)
    summary=dict(schema='cybrgeo-trajectory-policy-nominal-diagnostic/1',passed=all(x['passed'] for x in checks),
        checks=checks,model_sha256=result['model_sha256'],control_sha256=result['control_sha256'],
        reference_sha256=result['reference_sha256'],reference_source=provenance,duration_s=result['duration_s'],
        metrics=result['metrics'],peak_belt_Nm=peak_belt.tolist(),scope='Nominal targeted check; fault suite separate; no hardware qualification')
    diagnostic.write(out/'diagnosis.json',summary)
    (out/'frames.json.gz').write_bytes(gzip.compress(json.dumps(result['frames'],separators=(',',':'),allow_nan=False).encode(),mtime=0))
    print(json.dumps(dict(nominal=True,passed=summary['passed'],failed=[x for x in checks if not x['passed']],
        duration_s=result['duration_s'],peak_belt_Nm=peak_belt.tolist())),flush=True)
    return summary

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--policy',choices=['source','no-flourish'],required=True)
    parser.add_argument('--transfer',type=float,default=1.)
    parser.add_argument('--descent',type=float,default=1.)
    parser.add_argument('--nominal-only',action='store_true')
    args=parser.parse_args()
    snapshot_path=diagnostic.ROOT/'outputs/fault-diagnosis/baseline-pinned-runtime-1c216fda.json'
    snapshot=json.loads(snapshot_path.read_text())
    for name,expected in snapshot['services_sha256'].items():
        assert diagnostic.sha(diagnostic.ROOT/'outputs/fault-diagnosis/baseline_runtime'/name)==expected, f'Baseline runtime changed: {name}'
    physical=PhysicalModel.from_source(snapshot['physical_source']); control=snapshot['control']; p=snapshot['parameters']
    assert digest(physical.to_source())==snapshot['model_sha256']
    text=snapshot['task_source']
    if args.policy=='no-flourish':
        for old,new in [('direction = [.15 * hump, -1, direction_sign * .34 * hump]','direction = [0., -1., 0.]'),
                        ('q6 += direction_sign * .5 * hump','q6 += 0.0')]:
            assert text.count(old)==1
            text=text.replace(old,new)
    namespace={}
    exec(compile(text,'<retained-task-policy-diagnostic>','exec'),namespace)
    forward,inverse,mapping=time_map(args.transfer,args.descent)
    provenance=dict(baseline_head=snapshot['head'],baseline_snapshot_sha256=diagnostic.sha(snapshot_path),
        baseline_model_sha256=snapshot['model_sha256'],baseline_control_sha256=snapshot['control_sha256'],
        services_sha256=snapshot['services_sha256'],policy=args.policy,policy_task_source=text,retiming=mapping,
        diagnostic_script_sha256=diagnostic.sha(__file__),measurement_script_sha256=diagnostic.sha(diagnostic.__file__),
        scope='Historical 1c216fda physical baseline; in-memory trajectory variant; not a new source-bound native build')
    def reference(t):
        phase,rate=inverse(t); target=namespace['reference'](phase,p)
        target['qd']=[x*rate for x in target['qd']]; target['qdd']=[x*rate*rate for x in target['qdd']]
        return target
    out=diagnostic.ROOT/'outputs/fault-diagnosis'/f'policy-{args.policy}-transfer-{args.transfer:g}-descent-{args.descent:g}'
    print(json.dumps(dict(baseline_loaded=True,policy=args.policy,period_s=forward(10.))),flush=True)
    nominal_result=nominal(physical,control,p,reference,provenance,forward,out/'nominal')
    rows=[]
    if not args.nominal_only:
        for name,(_,base_options) in list(diagnostic.CASES.items()):
            for scope in (['original-clock'] if args.transfer==args.descent==1 else ['original-clock','matched-phase']):
                options=dict(base_options)
                if scope=='matched-phase': options['motorOffTime']=forward(options['motorOffTime'])
                label=name+'--'+scope; diagnostic.CASES[label]=(options['motorOffTime']+1.2,options)
                r=diagnostic.diagnose(label,physical,control,p,reference,provenance,out/label)
                rows.append(dict(case=name,scope=scope,fault_s=options['motorOffTime'],passed=r['passed'],
                    peak_belt_Nm=r['peak_belt_Nm'],max_settled_speed_sampled_rad_s=r['max_settled_speed_sampled_rad_s'],
                    failed=[c['name'] for c in r['checks'] if not c['passed']],puck_drop_m=r['max_fault_puck_drop_m']))
    diagnostic.write(out/'summary.json',dict(provenance=provenance,nominal_passed=nominal_result['passed'],scenarios=rows))
    print(json.dumps(rows,indent=2),flush=True)

if __name__=='__main__': main()
