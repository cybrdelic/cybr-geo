"""Retain immutable Git runtime blobs and create a distinct pinned baseline.

The earlier snapshot captured a concurrently edited runtime. It is retained
unchanged; its physical/native records are reused, but its runtime is not
represented as the pinned Git version.
"""
from pathlib import Path
import hashlib, json, subprocess
root=Path(__file__).resolve().parents[2]
snapshot=json.loads((root/'outputs/fault-diagnosis/baseline-1c216fda.json').read_text())
out=Path(__file__).with_name('baseline_runtime')
out.mkdir(exist_ok=True)
(out/'__init__.py').write_text('',encoding='utf-8')
actual_commit=subprocess.check_output(['git','rev-parse',snapshot['head']+'^{commit}'],cwd=root,text=True).strip()
assert actual_commit=='1c216fdaebf14c68c0a0cb5dde794cd4ada7a06a'
service_hashes={}
for name in snapshot['services_sha256']:
    blob=subprocess.check_output(['git','show',snapshot['head']+':src/mechanism_lab/'+name],cwd=root)
    actual=hashlib.sha256(blob).hexdigest()
    (out/name).write_bytes(blob)
    service_hashes[name]=actual
    print(name,actual,flush=True)
snapshot['observed_working_tree_services_sha256']=snapshot['services_sha256']
snapshot['services_sha256']=service_hashes
snapshot['runtime_origin']=dict(commit=actual_commit,source='git show immutable commit blobs; original LF bytes',
    earlier_snapshot_sha256=hashlib.sha256((root/'outputs/fault-diagnosis/baseline-1c216fda.json').read_bytes()).hexdigest())
snapshot['scope']='New diagnostic baseline: verified physical/native snapshot with exact immutable 1c216fda Git runtime; earlier exploratory runtime identity is not asserted'
target=root/'outputs/fault-diagnosis/baseline-pinned-runtime-1c216fda.json'
assert not target.exists()
target.write_text(json.dumps(snapshot,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print('Pinned baseline snapshot:',hashlib.sha256(target.read_bytes()).hexdigest(),flush=True)
